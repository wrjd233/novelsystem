<?php
class Captcha {
    private $code;
    private $image;
    
    public function __construct() {
        $this->generateCode();
        $this->createImage();
    }
    
    // 生成验证码
    private function generateCode() {
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $this->code = '';
        for ($i = 0; $i < CAPTCHA_LEN; $i++) {
            $this->code .= $chars[rand(0, strlen($chars) - 1)];
        }
        $_SESSION['captcha_code'] = $this->code;
    }
    
    // 创建验证码图片
    private function createImage() {
        $width = 120;
        $height = 40;
        
        $this->image = imagecreate($width, $height);
        
        // 设置颜色
        $bg_color = imagecolorallocate($this->image, 255, 255, 255);
        $text_color = imagecolorallocate($this->image, 0, 0, 0);
        $line_color = imagecolorallocate($this->image, 128, 128, 128);
        
        // 添加干扰线
        for ($i = 0; $i < 5; $i++) {
            imageline($this->image, rand(0, $width), rand(0, $height), 
                     rand(0, $width), rand(0, $height), $line_color);
        }
        
        // 添加验证码文字
        imagestring($this->image, 5, 30, 12, $this->code, $text_color);
    }
    
    // 输出图片
    public function output() {
        header('Content-Type: image/png');
        imagepng($this->image);
        imagedestroy($this->image);
    }
    
    // 验证验证码
    public static function verify($input) {
        if (!isset($_SESSION['captcha_code'])) {
            return false;
        }
        
        $result = strtoupper($input) === $_SESSION['captcha_code'];
        unset($_SESSION['captcha_code']); // 验证后清除
        return $result;
    }
}
?>