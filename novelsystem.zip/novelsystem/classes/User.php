<?php
require_once __DIR__ . '/../config/database.php';

class User {
    private $conn;
    private $table_name = "users";
    
    public $user_id;
    public $username;
    public $email;
    public $password_hash;
    public $is_admin;
    public $points;
    public $created_at;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // 用户注册
    public function register($username, $email, $password) {
        // 验证输入
        if (!$this->validateUsername($username)) {
            return ['success' => false, 'message' => '用户名格式无效（3-20字符，字母数字下划线）'];
        }
        
        if (!$this->validateEmail($email)) {
            return ['success' => false, 'message' => '邮箱格式无效'];
        }
        
        if (!$this->validatePassword($password)) {
            return ['success' => false, 'message' => '密码强度不够（至少6字符，包含大小写字母和数字）'];
        }
        
        // 检查用户名和邮箱是否已存在
        if ($this->usernameExists($username)) {
            return ['success' => false, 'message' => '用户名已存在'];
        }
        
        if ($this->emailExists($email)) {
            return ['success' => false, 'message' => '邮箱已注册'];
        }
        
        // 创建用户
        $query = "INSERT INTO " . $this->table_name . " 
                  (username, email, password_hash, points) 
                  VALUES (:username, :email, :password_hash, 0)";
        
        $stmt = $this->conn->prepare($query);
        
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password_hash', $password_hash);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => '注册成功'];
        }
        
        return ['success' => false, 'message' => '注册失败'];
    }
    
    // 用户登录
    public function login($username, $password) {
        $query = "SELECT user_id, username, email, password_hash, is_admin, points 
                  FROM " . $this->table_name . " 
                  WHERE username = :username";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (password_verify($password, $row['password_hash'])) {
                $this->user_id = $row['user_id'];
                $this->username = $row['username'];
                $this->email = $row['email'];
                $this->is_admin = $row['is_admin'];
                $this->points = $row['points'];
                
                // 设置会话
                $_SESSION['user_id'] = $this->user_id;
                $_SESSION['username'] = $this->username;
                $_SESSION['is_admin'] = $this->is_admin;
                $_SESSION['points'] = $this->points;
                $_SESSION['login_time'] = time();
                
                return ['success' => true, 'message' => '登录成功'];
            }
        }
        
        return ['success' => false, 'message' => '用户名或密码错误'];
    }
    
    // 验证用户名格式
    private function validateUsername($username) {
        return preg_match('/^[a-zA-Z][a-zA-Z0-9_]{2,19}$/', $username);
    }
    
    // 验证邮箱格式
    private function validateEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
    
    // 验证密码强度
    private function validatePassword($password) {
        if (strlen($password) < 6) return false;
        
        $hasUpper = preg_match('/[A-Z]/', $password);
        $hasLower = preg_match('/[a-z]/', $password);
        $hasDigit = preg_match('/[0-9]/', $password);
        
        return ($hasUpper + $hasLower + $hasDigit) >= 2;
    }
    
    // 检查用户名是否存在
    private function usernameExists($username) {
        $query = "SELECT user_id FROM " . $this->table_name . " WHERE username = :username";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        return $stmt->rowCount() > 0;
    }
    
    // 检查邮箱是否存在
    private function emailExists($email) {
        $query = "SELECT user_id FROM " . $this->table_name . " WHERE email = :email";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        return $stmt->rowCount() > 0;
    }
    
    // 获取用户积分
    public function getPoints($user_id) {
        $query = "SELECT points FROM " . $this->table_name . " WHERE user_id = :user_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row['points'];
        }
        return 0;
    }
    
    // 更新用户积分
    public function updatePoints($user_id, $points) {
        $query = "UPDATE " . $this->table_name . " SET points = :points WHERE user_id = :user_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':points', $points);
        $stmt->bindParam(':user_id', $user_id);
        return $stmt->execute();
    }
    
    // 检查是否登录
    public static function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }
    
    // 检查是否为管理员
    public static function isAdmin() {
        return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;
    }
    
    // 登出
    public static function logout() {
        session_destroy();
    }
}
?>