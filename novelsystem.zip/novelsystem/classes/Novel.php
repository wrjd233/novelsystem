<?php
require_once __DIR__ . '/../config/database.php';

class Novel {
    private $conn;
    private $table_name = "novels";
    
    public $novel_id;
    public $title;
    public $author;
    public $content;
    public $word_count;
    public $storage_type;
    public $created_by;
    public $created_at;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // 发布小说
    public function publish($title, $author, $content, $created_by) {
        if (!$this->validateTitle($title)) {
            return ['success' => false, 'message' => '标题格式无效（1-199字符）'];
        }
        
        if (!$this->validateAuthor($author)) {
            return ['success' => false, 'message' => '作者名格式无效（1-99字符）'];
        }
        
        if (!$this->validateContent($content)) {
            return ['success' => false, 'message' => '内容不能为空'];
        }
        
        $word_count = $this->countWords($content);
        $storage_type = $this->determineStorageType($word_count);
        
        $query = "INSERT INTO " . $this->table_name . " 
                  (title, author, content, word_count, storage_type, created_by) 
                  VALUES (:title, :author, :content, :word_count, :storage_type, :created_by)";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':author', $author);
        $stmt->bindParam(':content', $content);
        $stmt->bindParam(':word_count', $word_count);
        $stmt->bindParam(':storage_type', $storage_type);
        $stmt->bindParam(':created_by', $created_by);
        
        if ($stmt->execute()) {
            return [
                'success' => true, 
                'message' => '小说发布成功',
                'novel_id' => $this->conn->lastInsertId(),
                'word_count' => $word_count
            ];
        }
        
        return ['success' => false, 'message' => '发布失败'];
    }
    
    // 获取所有小说
    public function getAllNovels($page = 1, $limit = 10) {
        $offset = ($page - 1) * $limit;
        
        $query = "SELECT novel_id, title, author, content, word_count, storage_type, created_at 
                  FROM " . $this->table_name . " 
                  ORDER BY created_at DESC 
                  LIMIT :limit OFFSET :offset";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // 搜索小说（使用FULLTEXT索引）
    public function searchNovels($keyword, $type = 'fulltext') {
        switch ($type) {
            case 'title':
                $query = "SELECT novel_id, title, author, content, word_count, storage_type, created_at 
                          FROM " . $this->table_name . " 
                          WHERE title LIKE :keyword 
                          ORDER BY created_at DESC";
                break;
            case 'author':
                $query = "SELECT novel_id, title, author, content, word_count, storage_type, created_at 
                          FROM " . $this->table_name . " 
                          WHERE author LIKE :keyword 
                          ORDER BY created_at DESC";
                break;
            default: // fulltext
                $query = "SELECT novel_id, title, author, content, word_count, storage_type, created_at 
                          FROM " . $this->table_name . " 
                          WHERE MATCH(title, author, content) AGAINST(:keyword IN NATURAL LANGUAGE MODE) 
                          ORDER BY created_at DESC";
                break;
        }
        
        $stmt = $this->conn->prepare($query);
        
        if ($type == 'fulltext') {
            $stmt->bindParam(':keyword', $keyword);
        } else {
            $keyword_like = '%' . $keyword . '%';
            $stmt->bindParam(':keyword', $keyword_like);
        }
        
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // 根据ID获取小说
    public function getNovelById($novel_id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE novel_id = :novel_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':novel_id', $novel_id);
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }
        return null;
    }
    
    // 删除小说
    public function deleteNovel($novel_id, $user_id) {
        // 检查权限（管理员或作者本人）
        if (!User::isAdmin()) {
            $query = "SELECT created_by FROM " . $this->table_name . " WHERE novel_id = :novel_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':novel_id', $novel_id);
            $stmt->execute();
            
            if ($stmt->rowCount() > 0) {
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($row['created_by'] != $user_id) {
                    return ['success' => false, 'message' => '无权限删除此小说'];
                }
            } else {
                return ['success' => false, 'message' => '小说不存在'];
            }
        }
        
        // 先删除相关的 reading_records
        $delete_records_query = "DELETE FROM reading_records WHERE novel_id = :novel_id";
        $delete_stmt = $this->conn->prepare($delete_records_query);
        $delete_stmt->bindParam(':novel_id', $novel_id);
        $delete_stmt->execute();
        
        // 然后删除小说
        $query = "DELETE FROM " . $this->table_name . " WHERE novel_id = :novel_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':novel_id', $novel_id);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => '删除成功'];
        }
        
        return ['success' => false, 'message' => '删除失败'];
    }
    
    // 验证标题
    private function validateTitle($title) {
        return !empty(trim($title)) && strlen($title) <= MAX_TITLE_LEN;
    }
    
    // 验证作者
    private function validateAuthor($author) {
        return !empty(trim($author)) && strlen($author) <= MAX_AUTHOR_LEN;
    }
    
    // 验证内容
    private function validateContent($content) {
        return !empty(trim($content));
    }
    
    // 统计字数
    private function countWords($content) {
        // 中文字符按字计算，英文按单词计算
        $chinese_chars = preg_match_all('/[\x{4e00}-\x{9fff}]/u', $content);
        $english_words = str_word_count(preg_replace('/[\x{4e00}-\x{9fff}]/u', '', $content));
        return $chinese_chars + $english_words;
    }
    
    // 确定存储类型
    private function determineStorageType($word_count) {
        return $word_count > FREE_READING_WORDS ? 'paid' : 'free';
    }
    
    // 获取小说总数
    public function getTotalCount() {
        $query = "SELECT COUNT(*) as total FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'];
    }
    
    // 获取小说总数（别名方法，与admin.php保持一致）
    public function getTotalNovels() {
        return $this->getTotalCount();
    }
}
?>