<?php
require_once '../config/database.php';

class PointsSystem {
    private $conn;
    private $points_table = "points_records";
    private $cards_table = "card_codes";
    private $reading_table = "reading_records";
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // 添加积分记录
    public function addPointsRecord($user_id, $points_change, $description) {
        $query = "INSERT INTO " . $this->points_table . " 
                  (user_id, points_change, description) 
                  VALUES (:user_id, :points_change, :description)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':points_change', $points_change);
        $stmt->bindParam(':description', $description);
        
        return $stmt->execute();
    }
    
    // 获取积分历史
    public function getPointsHistory($user_id, $limit = 20) {
        $query = "SELECT points_change, description, created_at 
                  FROM " . $this->points_table . " 
                  WHERE user_id = :user_id 
                  ORDER BY created_at DESC 
                  LIMIT :limit";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // 创建卡密
    public function createCardCode($points_value, $quantity = 1) {
        $cards = [];
        
        for ($i = 0; $i < $quantity; $i++) {
            $card_code = $this->generateCardCode();
            
            $query = "INSERT INTO " . $this->cards_table . " 
                      (card_code, points_value) 
                      VALUES (:card_code, :points_value)";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':card_code', $card_code);
            $stmt->bindParam(':points_value', $points_value);
            
            if ($stmt->execute()) {
                $cards[] = $card_code;
            }
        }
        
        return $cards;
    }
    
    // 兑换卡密
    public function redeemCardCode($card_code, $user_id) {
        // 检查卡密是否存在且未使用
        $query = "SELECT card_id, points_value, is_used 
                  FROM " . $this->cards_table . " 
                  WHERE card_code = :card_code";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':card_code', $card_code);
        $stmt->execute();
        
        if ($stmt->rowCount() == 0) {
            return ['success' => false, 'message' => '卡密不存在'];
        }
        
        $card = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($card['is_used']) {
            return ['success' => false, 'message' => '卡密已被使用'];
        }
        
        // 开始事务
        $this->conn->beginTransaction();
        
        try {
            // 标记卡密为已使用
            $update_card = "UPDATE " . $this->cards_table . " 
                           SET is_used = 1, used_by = :user_id, used_at = NOW() 
                           WHERE card_code = :card_code";
            
            $stmt = $this->conn->prepare($update_card);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':card_code', $card_code);
            $stmt->execute();
            
            // 更新用户积分
            $user = new User($this->conn);
            $current_points = $user->getPoints($user_id);
            $new_points = $current_points + $card['points_value'];
            $user->updatePoints($user_id, $new_points);
            
            // 添加积分记录
            $this->addPointsRecord($user_id, $card['points_value'], "卡密兑换：" . $card_code);
            
            $this->conn->commit();
            
            return [
                'success' => true, 
                'message' => '兑换成功，获得 ' . $card['points_value'] . ' 积分',
                'points_gained' => $card['points_value']
            ];
            
        } catch (Exception $e) {
            $this->conn->rollback();
            return ['success' => false, 'message' => '兑换失败'];
        }
    }
    
    // 计算阅读费用
    public function calculateReadingCost($words_to_read) {
        if ($words_to_read <= FREE_READING_WORDS) {
            return 0;
        }
        
        $paid_words = $words_to_read - FREE_READING_WORDS;
        return ceil($paid_words / 3000);
    }
    
    // 检查阅读权限
    function checkReadingPermission($user_id, $novel_id, $words_to_read) {
        $reading_record = $this->getReadingRecord($user_id, $novel_id);
        if ($reading_record && $reading_record['is_purchased']) {
            return ['allowed' => true, 'cost' => 0, 'message' => '已购买'];
        }
        // 获取阅读记录
        $reading_record = $this->getReadingRecord($user_id, $novel_id);
        
        $free_words_used = $reading_record ? $reading_record['free_words_used'] : 0;
        $remaining_free_words = max(0, FREE_READING_WORDS - $free_words_used);
        
        if ($words_to_read <= $remaining_free_words) {
            return ['allowed' => true, 'cost' => 0, 'free_words' => $words_to_read];
        }
        
        $paid_words = $words_to_read - $remaining_free_words;
        $cost = $this->calculateReadingCost($paid_words + FREE_READING_WORDS) - $this->calculateReadingCost(FREE_READING_WORDS);
        
        $user = new User($this->conn);
        $user_points = $user->getPoints($user_id);
        
        if ($user_points >= $cost) {
            return [
                'allowed' => true, 
                'cost' => $cost, 
                'free_words' => $remaining_free_words,
                'paid_words' => $paid_words
            ];
        }
        
        return [
            'allowed' => false, 
            'cost' => $cost, 
            'user_points' => $user_points,
            'message' => '积分不足'
        ];
    }
    
    // 获取阅读记录
    private function getReadingRecord($user_id, $novel_id) {
        $query = "SELECT * FROM " . $this->reading_table . " 
                  WHERE user_id = :user_id AND novel_id = :novel_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':novel_id', $novel_id);
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }
        return null;
    }
    
    // 更新阅读记录
    public function updateReadingRecord($user_id, $novel_id, $words_read, $free_words_used, $points_cost) {
        $this->conn->beginTransaction();
        
        try {
            // 更新或创建阅读记录
            $query = "INSERT INTO " . $this->reading_table . " 
                      (user_id, novel_id, words_read, free_words_used) 
                      VALUES (:user_id, :novel_id, :words_read, :free_words_used) 
                      ON DUPLICATE KEY UPDATE 
                      words_read = :words_read, 
                      free_words_used = :free_words_used, 
                      last_read_at = NOW()";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':novel_id', $novel_id);
            $stmt->bindParam(':words_read', $words_read);
            $stmt->bindParam(':free_words_used', $free_words_used);
            $stmt->execute();
            
            // 扣除积分
            if ($points_cost > 0) {
                $user = new User($this->conn);
                $current_points = $user->getPoints($user_id);
                $new_points = $current_points - $points_cost;
                $user->updatePoints($user_id, $new_points);
                
                // 添加积分记录
                $this->addPointsRecord($user_id, -$points_cost, "阅读小说消费");
            }
            
            $this->conn->commit();
            return true;
            
        } catch (Exception $e) {
            $this->conn->rollback();
            return false;
        }
    }
    
    // 生成卡密
    private function generateCardCode() {
        return strtoupper(substr(md5(uniqid(rand(), true)), 0, 16));
    }
    
    public function buyNovel($user_id, $novel_id) {
        $novel = new Novel($this->conn);
        $novelData = $novel->getNovelById($novel_id);
        if (!$novelData) {
            return ['success' => false, 'message' => '小说不存在'];
        }
        
        $total_words = $novelData['word_count'];
        $cost = $this->calculateReadingCost($total_words);
        
        $user = new User($this->conn);
        $user_points = $user->getPoints($user_id);
        if ($user_points < $cost) {
            return ['success' => false, 'message' => '积分不足'];
        }
        
        $this->conn->beginTransaction();
        try {
            // 扣除积分
            $new_points = $user_points - $cost;
            $user->updatePoints($user_id, $new_points);
            
            // 更新阅读记录为已购买
            $query = "UPDATE " . $this->reading_table . " 
                      SET is_purchased = 1 
                      WHERE user_id = :user_id AND novel_id = :novel_id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':novel_id', $novel_id);
            $stmt->execute();
            
            if ($stmt->rowCount() == 0) {
                // 如果没有记录，插入新记录
                $insert_query = "INSERT INTO " . $this->reading_table . " 
                                 (user_id, novel_id, is_purchased) 
                                 VALUES (:user_id, :novel_id, 1)";
                $insert_stmt = $this->conn->prepare($insert_query);
                $insert_stmt->bindParam(':user_id', $user_id);
                $insert_stmt->bindParam(':novel_id', $novel_id);
                $insert_stmt->execute();
            }
            
            // 添加积分记录
            $this->addPointsRecord($user_id, -$cost, "购买小说: " . $novelData['title']);
            
            $this->conn->commit();
            return ['success' => true, 'message' => '购买成功'];
        } catch (Exception $e) {
            $this->conn->rollback();
            return ['success' => false, 'message' => '购买失败'];
        }
    }
}
?>