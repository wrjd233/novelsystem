<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../classes/User.php';
require_once '../classes/Novel.php';
require_once '../classes/PointsSystem.php';
require_once '../classes/Captcha.php';  // 添加这一行

$database = new Database();
$db = $database->getConnection();

$page = isset($_GET['page']) ? $_GET['page'] : 'home';
$action = isset($_GET['action']) ? $_GET['action'] : '';

// 处理POST请求
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    switch ($action) {
        case 'login':
            $user = new User($db);
            $result = $user->login($_POST['username'], $_POST['password']);
            $message = $result['message'];
            $message_type = $result['success'] ? 'success' : 'error';
            break;
            
        case 'register':
            if (isset($_POST['captcha']) && Captcha::verify($_POST['captcha'])) {
                $user = new User($db);
                $result = $user->register($_POST['username'], $_POST['email'], $_POST['password']);
                $message = $result['message'];
                $message_type = $result['success'] ? 'success' : 'error';
            } else {
                $message = '验证码错误';
                $message_type = 'error';
            }
            break;
            
        case 'publish':
            if (User::isAdmin()) {
                $novel = new Novel($db);
                $result = $novel->publish($_POST['title'], $_POST['author'], $_POST['content'], $_SESSION['user_id']);
                $message = $result['message'];
                $message_type = $result['success'] ? 'success' : 'error';
            }
            break;
            
        case 'redeem':
            if (User::isLoggedIn()) {
                $points = new PointsSystem($db);
                $result = $points->redeemCardCode($_POST['card_code'], $_SESSION['user_id']);
                $message = $result['message'];
                $message_type = $result['success'] ? 'success' : 'error';
                
                if ($result['success']) {
                    $_SESSION['points'] = (new User($db))->getPoints($_SESSION['user_id']);
                }
            }
            break;
        case 'delete_novel':
            if (User::isAdmin()) {
                $novel = new Novel($db);
                $result = $novel->deleteNovel($_POST['novel_id'], $_SESSION['user_id']);
                $message = $result['message'];
                $message_type = $result['success'] ? 'success' : 'error';
            }
            break;
        case 'generate_card':
            if (User::isAdmin()) {
                $points = new PointsSystem($db);
                $cards = $points->createCardCode($_POST['points_value'], $_POST['quantity']);
                $message = '生成的卡密: ' . implode(', ', $cards);
                $message_type = 'success';
            } else {
                $message = '无权限生成卡密';
                $message_type = 'error';
            }
            break;
            
        case 'buy_novel':
            if (User::isLoggedIn()) {
                $points = new PointsSystem($db);
                $result = $points->buyNovel($_SESSION['user_id'], $_POST['novel_id']);
                $message = $result['message'];
                $message_type = $result['success'] ? 'success' : 'error';
                
                if ($result['success']) {
                    $_SESSION['points'] = (new User($db))->getPoints($_SESSION['user_id']);
                    // 可选: 重定向到小说页面以刷新
                    header('Location: index.php?page=novel&id=' . $_POST['novel_id']);
                    exit;
                }
            }
            break;
            
    }
}

// 处理登出
if ($action === 'logout') {
    User::logout();
    header('Location: index.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .novel-card {
            transition: transform 0.2s;
        }
        .novel-card:hover {
            transform: translateY(-5px);
        }
        .reading-area {
            line-height: 1.8;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php"><?php echo APP_NAME; ?></a>
            
            <div class="navbar-nav ms-auto">
                <?php if (User::isLoggedIn()): ?>
                    <span class="navbar-text me-3">
                        欢迎，<?php echo $_SESSION['username']; ?> 
                        (积分: <?php echo $_SESSION['points']; ?>)
                    </span>
                    <?php if (User::isAdmin()): ?>
                        <a class="nav-link" href="?page=admin">管理面板</a>
                    <?php endif; ?>
                    <a class="nav-link" href="?page=profile">个人中心</a>
                    <a class="nav-link" href="?action=logout">登出</a>
                <?php else: ?>
                    <a class="nav-link" href="?page=login">登录</a>
                    <a class="nav-link" href="?page=register">注册</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (isset($message)): ?>
            <div class="alert alert-<?php echo $message_type === 'success' ? 'success' : 'danger'; ?> alert-dismissible fade show">
                <?php echo htmlspecialchars($message); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php
        // 根据页面参数包含相应的页面
        switch ($page) {
            case 'login':
                include 'pages/login.php';
                break;
            case 'register':
                include 'pages/register.php';
                break;
            case 'novels':
                include 'pages/novels.php';
                break;
            case 'novel':
                include 'pages/novel_detail.php';
                break;
            case 'search':
                include 'pages/search.php';
                break;
            case 'admin':
                if (User::isAdmin()) {
                    include 'pages/admin.php';
                } else {
                    echo '<div class="alert alert-danger">无权限访问</div>';
                }
                break;
            case 'profile':
                if (User::isLoggedIn()) {
                    include 'pages/profile.php';
                } else {
                    header('Location: ?page=login');
                }
                break;
            default:
                include 'pages/home.php';
                break;
        }
        ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>