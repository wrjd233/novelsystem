<?php
require_once '../config/config.php';
require_once '../classes/Captcha.php';

$captcha = new Captcha();
$captcha->output();
?>