<?php
$novel = new Novel($db);
$points = new PointsSystem($db);
$totalNovels = $novel->getTotalNovels();
?>

<div class="row">
    <div class="col-md-12">
        <h2>管理员面板</h2>
        
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card text-center">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $totalNovels; ?></h5>
                        <p class="card-text">总小说数</p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- 发布小说 -->
        <div class="card mb-4">
            <div class="card-header">
                <h5>发布新小说</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="?action=publish">
                    <div class="mb-3">
                        <label for="title" class="form-label">小说标题</label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                    <div class="mb-3">
                        <label for="author" class="form-label">作者</label>
                        <input type="text" class="form-control" id="author" name="author" required>
                    </div>
                    <div class="mb-3">
                        <label for="content" class="form-label">小说内容</label>
                        <textarea class="form-control" id="content" name="content" rows="10" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">发布小说</button>
                </form>
            </div>
        </div>
        
        <!-- 生成卡密 -->
        <div class="card">
            <div class="card-header">
                <h5>生成充值卡密</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="?action=generate_card">
                    <div class="row">
                        <div class="col-md-6">
                            <label for="points_value" class="form-label">积分面值</label>
                            <input type="number" class="form-control" id="points_value" name="points_value" min="1" required>
                        </div>
                        <div class="col-md-6">
                            <label for="quantity" class="form-label">生成数量</label>
                            <input type="number" class="form-control" id="quantity" name="quantity" min="1" max="100" value="1" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success mt-3">生成卡密</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- 小说管理 -->
<div class="card mt-4">
    <div class="card-header">
        <h5>小说管理</h5>
    </div>
    <div class="card-body">
        <?php
        $novels = $novel->getAllNovels();
        if (!empty($novels)):
        ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>标题</th>
                        <th>作者</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($novels as $n): ?>
                        <tr>
                            <td><?php echo $n['novel_id']; ?></td>
                            <td><?php echo htmlspecialchars($n['title']); ?></td>
                            <td><?php echo htmlspecialchars($n['author']); ?></td>
                            <td>
                                <form method="POST" action="?action=delete_novel" onsubmit="return confirm('确定删除此小说？');">
                                    <input type="hidden" name="novel_id" value="<?php echo $n['novel_id']; ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">删除</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>暂无小说</p>
        <?php endif; ?>
    </div>
</div>