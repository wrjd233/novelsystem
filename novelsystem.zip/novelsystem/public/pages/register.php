<?php require_once '../classes/Captcha.php'; ?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h4>用户注册</h4>
            </div>
            <div class="card-body">
                <form method="POST" action="?action=register">
                    <div class="mb-3">
                        <label for="username" class="form-label">用户名</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">邮箱</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">密码</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="mb-3">
                        <label for="captcha" class="form-label">验证码</label>
                        <div class="row">
                            <div class="col-6">
                                <input type="text" class="form-control" id="captcha" name="captcha" required>
                            </div>
                            <div class="col-6">
                                <img src="captcha.php" alt="验证码" onclick="this.src='captcha.php?'+Math.random()" style="cursor:pointer;">
                            </div>
                        </div>
                        <small class="form-text text-muted">点击图片刷新验证码</small>
                    </div>
                    <button type="submit" class="btn btn-primary">注册</button>
                    <a href="?page=login" class="btn btn-link">已有账号？登录</a>
                </form>
            </div>
        </div>
    </div>
</div>