<?php
if (!isset($_GET['id'])) {
    echo '<div class="alert alert-danger">小说ID不能为空</div>';
    return;
}

$novel = new Novel($db);
$novelData = $novel->getNovelById($_GET['id']);

if (!$novelData) {
    echo '<div class="alert alert-danger">小说不存在</div>';
    return;
}

$points = new PointsSystem($db);
$novel_id = $_GET['id'];
$cost = $points->calculateReadingCost($novelData['word_count']);

if (User::isLoggedIn()) {
    $permission = $points->checkReadingPermission($_SESSION['user_id'], $novel_id, $novelData['word_count']);
} else {
    $permission = ['allowed' => false, 'cost' => 0, 'message' => ''];
}
?>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h3><?php echo htmlspecialchars($novelData['title']); ?></h3>
                <p class="mb-0">
                    <small class="text-muted">
                        作者：<?php echo htmlspecialchars($novelData['author']); ?> | 
                        字数：<?php echo number_format($novelData['word_count']); ?> | 
                        发布时间：<?php echo $novelData['created_at']; ?>
                    </small>
                </p>
            </div>
            <div class="card-body">
                <?php if ($novelData['word_count'] > FREE_READING_WORDS && (!isset($permission['message']) || $permission['message'] !== '已购买')): ?>
                    <div class="alert alert-info">
                        <p>此小说总字数 <?php echo $novelData['word_count']; ?>，需要 <?php echo $cost; ?> 积分购买整个小说（免费阅读前3000字，每3000字1积分）。</p>
                        <?php if (User::isLoggedIn()): ?>
                            <form method="POST" action="index.php?action=buy_novel">
                                <input type="hidden" name="novel_id" value="<?php echo $novel_id; ?>">
                                <button type="submit" class="btn btn-primary">购买</button>
                            </form>
                        <?php else: ?>
                            <p>请登录后购买阅读全文。</p>
                        <?php endif; ?>
                    </div>
                    <div class="reading-area">
                        <?php echo nl2br(htmlspecialchars(mb_substr($novelData['content'], 0, FREE_READING_WORDS, 'UTF-8'))); ?>
                    </div>
                    <p class="text-muted">免费试读结束，购买后可阅读全文。</p>
                <?php else: ?>
                    <div class="reading-area">
                        <?php echo nl2br(htmlspecialchars($novelData['content'])); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5>小说信息</h5>
            </div>
            <div class="card-body">
                <p><strong>类型：</strong>
                    <?php if ($novelData['storage_type'] === 'paid'): ?>
                        <span class="badge bg-warning">付费小说</span>
                    <?php else: ?>
                        <span class="badge bg-success">免费小说</span>
                    <?php endif; ?>
                </p>
                <p><strong>字数：</strong><?php echo number_format($novelData['word_count']); ?></p>
                <p><strong>发布时间：</strong><?php echo $novelData['created_at']; ?></p>
                <?php if ($novelData['storage_type'] === 'paid'): ?>
                    <p><strong>阅读费用：</strong><?php echo $readingCost; ?> 积分</p>
                <?php endif; ?>
            </div>
        </div>
        
        <?php if (User::isAdmin()): ?>
            <div class="card mt-3">
                <div class="card-header">
                    <h5>管理操作</h5>
                </div>
                <div class="card-body">
                    <a href="?action=delete&id=<?php echo $_GET['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('确定要删除这篇小说吗？')">删除小说</a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>