<?php
$novel = new Novel($db);
$novels = $novel->getAllNovels();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>小说列表</h2>
    <a href="?page=search" class="btn btn-outline-primary">搜索小说</a>
</div>

<div class="row">
    <?php foreach ($novels as $n): ?>
        <div class="col-md-4 mb-4">
            <div class="card novel-card h-100">
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($n['title']); ?></h5>
                    <p class="card-text">
                        <small class="text-muted">作者：<?php echo htmlspecialchars($n['author']); ?></small><br>
                        <small class="text-muted">字数：<?php echo number_format($n['word_count']); ?></small><br>
                        <small class="text-muted">发布时间：<?php echo $n['created_at']; ?></small>
                    </p>
                    <p class="card-text"><?php echo htmlspecialchars(mb_substr($n['content'], 0, 100)) . '...'; ?></p>
                </div>
                <div class="card-footer">
                    <a href="?page=novel&id=<?php echo $n['id']; ?>" class="btn btn-primary btn-sm">阅读</a>
                    <?php if ($n['storage_type'] === 'paid'): ?>
                        <span class="badge bg-warning">付费</span>
                    <?php else: ?>
                        <span class="badge bg-success">免费</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<?php if (empty($novels)): ?>
    <div class="text-center">
        <p class="text-muted">暂无小说</p>
    </div>
<?php endif; ?>