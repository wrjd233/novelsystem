<?php
$user = new User($db);
$points = new PointsSystem($db);
$userPoints = $user->getPoints($_SESSION['user_id']);
$pointsHistory = $points->getPointsHistory($_SESSION['user_id']);
?>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5>个人信息</h5>
            </div>
            <div class="card-body">
                <p><strong>用户名：</strong><?php echo htmlspecialchars($_SESSION['username']); ?></p>
                <p><strong>当前积分：</strong><?php echo $userPoints; ?></p>
                <p><strong>注册时间：</strong><?php echo $_SESSION['created_at'] ?? '未知'; ?></p>
            </div>
        </div>
        
        <div class="card mt-4">
            <div class="card-header">
                <h5>积分历史</h5>
            </div>
            <div class="card-body">
                <?php if (!empty($pointsHistory)): ?>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>时间</th>
                                    <th>类型</th>
                                    <th>积分变化</th>
                                    <th>说明</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($pointsHistory as $record): ?>
                                    <tr>
                                        <td><?php echo $record['created_at']; ?></td>
                                        <td>
                                            <?php if ($record['points'] > 0): ?>
                                                <span class="badge bg-success">获得</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger">消费</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($record['points'] > 0): ?>
                                                <span class="text-success">+<?php echo $record['points']; ?></span>
                                            <?php else: ?>
                                                <span class="text-danger"><?php echo $record['points']; ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($record['description']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted">暂无积分记录</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5>充值积分</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="?action=redeem">
                    <div class="mb-3">
                        <label for="card_code" class="form-label">卡密</label>
                        <input type="text" class="form-control" id="card_code" name="card_code" placeholder="请输入卡密" required>
                    </div>
                    <button type="submit" class="btn btn-primary">兑换</button>
                </form>
                
                <hr>
                
                <div class="text-muted small">
                    <p><strong>积分说明：</strong></p>
                    <ul>
                        <li>免费阅读：<?php echo FREE_READING_WORDS; ?> 字</li>
                        <li>付费阅读：<?php echo POINTS_PER_1000_WORDS; ?> 积分/千字</li>
                        <li>积分可通过卡密充值获得</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>