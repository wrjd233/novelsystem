<?php
// 检查数据库连接是否存在
if (!isset($db)) {
    die('数据库连接未初始化');
}

$novel = new Novel($db);
$recent_novels = $novel->getAllNovels(1, 6);
$total_novels = $novel->getTotalCount();
?>

<div class="row">
    <div class="col-md-12">
        <div class="jumbotron bg-light p-5 rounded">
            <h1 class="display-4">欢迎来到织梦小说</h1>
            <p class="lead">发现精彩小说，享受阅读乐趣</p>
            <hr class="my-4">
            <p>目前共有 <strong><?php echo $total_novels; ?></strong> 部小说等待您的阅读</p>
            <a class="btn btn-primary btn-lg" href="?page=novels" role="button">开始阅读</a>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-12">
        <h3>最新小说</h3>
        <div class="row">
            <?php foreach ($recent_novels as $novel_item): ?>
                <div class="col-md-4 mb-3">
                    <div class="card novel-card h-100">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($novel_item['title']); ?></h5>
                            <p class="card-text">
                                <small class="text-muted">作者：<?php echo htmlspecialchars($novel_item['author']); ?></small><br>
                                <small class="text-muted">字数：<?php echo number_format($novel_item['word_count']); ?></small><br>
                                <small class="text-muted">发布时间：<?php echo date('Y-m-d', strtotime($novel_item['created_at'])); ?></small>
                            </p>
                            <a href="?page=novel&id=<?php echo $novel_item['novel_id']; ?>" class="btn btn-primary">阅读</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <?php if (count($recent_novels) >= 6): ?>
            <div class="text-center mt-3">
                <a href="?page=novels" class="btn btn-outline-primary">查看更多小说</a>
            </div>
        <?php endif; ?>
    </div>
</div>