<?php
$searchResults = [];
$searchQuery = '';

if (isset($_GET['q']) && !empty($_GET['q'])) {
    $searchQuery = $_GET['q'];
    $novel = new Novel($db);
    $searchResults = $novel->searchNovels($searchQuery);
}
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card">
            <div class="card-header">
                <h4>搜索小说</h4>
            </div>
            <div class="card-body">
                <form method="GET">
                    <input type="hidden" name="page" value="search">
                    <div class="input-group">
                        <input type="text" class="form-control" name="q" value="<?php echo htmlspecialchars($searchQuery); ?>" placeholder="输入小说标题、作者或内容关键词">
                        <button class="btn btn-primary" type="submit">搜索</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php if (!empty($searchQuery)): ?>
    <div class="mt-4">
        <h5>搜索结果 (<?php echo count($searchResults); ?> 条)</h5>
        
        <?php if (!empty($searchResults)): ?>
            <div class="row">
                <?php foreach ($searchResults as $novel): ?>
                    <div class="col-md-6 mb-3">
                        <div class="card">
                            <div class="card-body">
                                <h6 class="card-title"><?php echo htmlspecialchars($novel['title']); ?></h6>
                                <p class="card-text">
                                    <small class="text-muted">作者：<?php echo htmlspecialchars($novel['author']); ?></small><br>
                                    <small class="text-muted">字数：<?php echo number_format($novel['word_count']); ?></small>
                                </p>
                                <p class="card-text"><?php echo htmlspecialchars(mb_substr($novel['content'], 0, 100)) . '...'; ?></p>
                                <a href="?page=novel&id=<?php echo $novel['id']; ?>" class="btn btn-primary btn-sm">阅读</a>
                                <?php if ($novel['storage_type'] === 'paid'): ?>
                                    <span class="badge bg-warning">付费</span>
                                <?php else: ?>
                                    <span class="badge bg-success">免费</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="alert alert-info">没有找到相关小说</div>
        <?php endif; ?>
    </div>
<?php endif; ?>