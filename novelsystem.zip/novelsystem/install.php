<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/classes/User.php';

$database = new Database();
$db = $database->getConnection();

if (!$db) {
    die('数据库连接失败');
}

echo "<h2>小说管理系统 - 数据库初始化</h2>";

// 创建用户表
$sql_users = "
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    is_admin TINYINT DEFAULT 0,
    points INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

try {
    $db->exec($sql_users);
    echo "<p>✓ 用户表创建成功</p>";
} catch (PDOException $e) {
    echo "<p>✗ 用户表创建失败: " . $e->getMessage() . "</p>";
}

// 创建小说表（使用 FULLTEXT）
$sql_novels = "
CREATE TABLE IF NOT EXISTS novels (
    novel_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    author VARCHAR(100) NOT NULL,
    content LONGTEXT NOT NULL,
    word_count INT DEFAULT 0,
    storage_type ENUM('free', 'paid') DEFAULT 'free',
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(user_id),
    FULLTEXT(title, author, content)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

try {
    $db->exec($sql_novels);
    echo "<p>✓ 小说表创建成功</p>";
} catch (PDOException $e) {
    echo "<p>✗ 小说表创建失败: " . $e->getMessage() . "</p>";
}

// 创建积分记录表
$sql_points = "
CREATE TABLE IF NOT EXISTS points_records (
    record_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    points_change INT NOT NULL,
    description VARCHAR(256),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($db->exec($sql_points) !== false) {
    echo "<p>✓ 积分记录表创建成功</p>";
} else {
    echo "<p>✗ 积分记录表创建失败</p>";
}

// 创建卡密表
$sql_cards = "
CREATE TABLE IF NOT EXISTS card_codes (
    card_id INT AUTO_INCREMENT PRIMARY KEY,
    card_code VARCHAR(32) UNIQUE NOT NULL,
    points_value INT NOT NULL,
    is_used TINYINT DEFAULT 0,
    used_by INT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    used_at DATETIME DEFAULT NULL,
    FOREIGN KEY (used_by) REFERENCES users(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($db->exec($sql_cards) !== false) {
    echo "<p>✓ 卡密表创建成功</p>";
} else {
    echo "<p>✗ 卡密表创建失败</p>";
}

// 创建阅读记录表
$sql_reading = "
CREATE TABLE IF NOT EXISTS reading_records (
    record_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    novel_id INT NOT NULL,
    words_read INT DEFAULT 0,
    free_words_used INT DEFAULT 0,
    last_read_at DATETIME DEFAULT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (novel_id) REFERENCES novels(novel_id),
    UNIQUE KEY unique_user_novel (user_id, novel_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($db->exec($sql_reading) !== false) {
    echo "<p>✓ 阅读记录表创建成功</p>";
} else {
    echo "<p>✗ 阅读记录表创建失败</p>";
}

// 创建默认管理员
$admin_password = password_hash('admin123', PASSWORD_DEFAULT);
$sql_admin = "INSERT IGNORE INTO users (username, email, password_hash, is_admin, points) 
              VALUES ('admin', 'admin@example.com', :password, 1, 1000)";

$stmt = $db->prepare($sql_admin);
$stmt->bindParam(':password', $admin_password);

if ($stmt->execute()) {
    echo "<p>✓ 默认管理员账户创建成功</p>";
} else {
    echo "<p>✗ 默认管理员账户创建失败</p>";
}

echo "<h3>安装完成！</h3>";
?>
//安装方法1.直接导入数据表.sql后修改database.php中数据库为自己数据库,安装后设置运行目录为/public

//安装方法2.
//修改/config/database.php中的数据库为自己的mysql 建议5.7 使用utf8mb4
//数据库安装可以使用install.php,安装后设置运行目录为/public
//默认账号密码为admin   admin123