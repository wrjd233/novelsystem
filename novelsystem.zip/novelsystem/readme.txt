//安装方法1.直接导入数据表.sql后修改database.php中数据库为自己数据库,安装后设置运行目录为/public

//安装方法2.
//修改/config/database.php中的数据库为自己的mysql 建议5.7 使用utf8mb4
//数据库安装可以使用install.php,安装后设置运行目录为/public
//默认账号密码为admin   admin123