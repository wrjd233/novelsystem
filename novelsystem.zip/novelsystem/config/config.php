<?php
// 应用配置
define('APP_NAME', 'Novel Management System');
define('APP_VERSION', '1.0.0');
define('BASE_URL', 'http://localhost/novel_system_php/');

// 数据库配置
define('DB_HOST', 'my.03184.com');
define('DB_NAME', 'mysql202507022');
define('DB_USER', 'mysql202507022');
define('DB_PASS', 'AHbDszHj78P4dphW');
define('DB_PORT', 3306);

// 系统常量
define('FREE_READING_WORDS', 3000);
define('POINTS_PER_1000_WORDS', 10);
define('MAX_USERNAME_LEN', 50);
define('MAX_EMAIL_LEN', 100);
define('MAX_TITLE_LEN', 200);
define('MAX_AUTHOR_LEN', 100);
define('CAPTCHA_LEN', 6);

// 会话配置
ini_set('session.cookie_lifetime', 86400); // 24小时
session_start();
?>